package com.library.controller;

import com.library.entity.Category;
import com.library.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
public class CategoryController {

    private final CategoryRepository repository;

    @PostMapping
    public Category create(
            @RequestBody Category category) {

        return repository.save(category);
    }

    @GetMapping
    public List<Category> getAll() {

        return repository.findAll();
    }
}
