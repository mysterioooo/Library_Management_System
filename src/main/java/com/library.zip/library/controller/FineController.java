package com.library.controller;

import com.library.entity.Fine;
import com.library.qr.QRCodeService;
import com.library.repository.FineRepository;
import com.library.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/fines")
@RequiredArgsConstructor
public class FineController {

    private final UserService service;
    private final FineRepository fineRepository;
    private final QRCodeService qrCodeService;

    @GetMapping
    public List<Fine> getAllFines() {

        return fineRepository.findAll();
    }

    @PostMapping("/pay/{fineId}")
    public String payFine(
            @PathVariable Long fineId){

        service.payFine(fineId);

        return "Fine Paid";
    }

    @GetMapping(
            value = "/qr/{fineId}",
            produces = MediaType.IMAGE_PNG_VALUE)
    public byte[] generateQR(
            @PathVariable Long fineId)
            throws Exception {

        Fine fine =
                fineRepository.findById(fineId)
                        .orElseThrow();

        String qrData =
                "Fine ID: "
                        + fine.getId()
                        + "\nAmount: "
                        + fine.getAmount();

        return qrCodeService
                .generateQRCode(qrData);
    }
}