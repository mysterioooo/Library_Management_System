package com.library.controller;

import com.library.dto.ReservationRequest;
import com.library.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/reservations")
@RequiredArgsConstructor
public class ReservationController {

    private final UserService service;

    @PostMapping
    public String reserveBook(
            @RequestBody
            ReservationRequest request){

        service.reserveBook(request);

        return "Book Reserved";
    }
}
