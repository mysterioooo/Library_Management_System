package com.library.controller;

import com.library.dto.DashboardDTO;
import com.library.dto.ReservationRequest;
import com.library.dto.UserResponseDTO;
import com.library.entity.IssueBook;
import com.library.repository.IssueBookRepository;
import com.library.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService service;
    private final IssueBookRepository issueBookRepository;

    @GetMapping
    public List<UserResponseDTO> getUsers() {

        return service.getAllUsers();
    }

    @DeleteMapping("/{id}")
    public void deleteUser(
            @PathVariable Long id) {

        service.deleteUser(id);
    }

    @PostMapping("/reserve")
    public String reserveBook(
            @RequestBody
            ReservationRequest request){

        service.reserveBook(request);

        return "Book Reserved";
    }

    @GetMapping("/dashboard")
    public DashboardDTO dashboard() {

        return service.dashboard();
    }

    @PostMapping("/pay/{fineId}")
    public String payFine(
            @PathVariable Long fineId){

        service.payFine(fineId);

        return "Fine Paid";
    }

    @GetMapping("/history/{userId}")
    public List<IssueBook> history(
            @PathVariable Long userId){

        return issueBookRepository.findByUser_Id(userId);
    }
}