package com.library.controller;

import com.library.dto.IssueBookRequest;
import com.library.entity.IssueBook;
import com.library.repository.IssueBookRepository;
import com.library.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/issues")
@RequiredArgsConstructor
public class IssueBookController {

    private final BookService service;
    private final IssueBookRepository repository;

    @PostMapping
    public String issueBook(
            @RequestBody
            IssueBookRequest request){

        service.issueBook(request);

        return "Book Issued";
    }

    @PostMapping("/return/{issueId}")
    public String returnBook(
            @PathVariable Long issueId){

        service.returnBook(issueId);

        return "Book Returned";
    }

    @GetMapping("/history/{userId}")
    public List<IssueBook> history(
            @PathVariable Long userId){

        return repository
                .findByUser_Id(userId);
    }
}
