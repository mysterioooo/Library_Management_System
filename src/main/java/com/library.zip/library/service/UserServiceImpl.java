package com.library.service;

import com.library.dto.DashboardDTO;
import com.library.dto.ReservationRequest;
import com.library.dto.UserResponseDTO;
import com.library.entity.Book;
import com.library.entity.Fine;
import com.library.entity.Reservation;
import com.library.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ReservationRepository reservationRepository;
    private final BookRepository bookRepository;
    private final IssueBookRepository issueRepository;
    private final FineRepository fineRepository;

    @Override
    public List<UserResponseDTO> getAllUsers() {

        return userRepository.findAll()
                .stream()
                .map(user -> {
                    UserResponseDTO dto = new UserResponseDTO();

                    dto.setId(user.getId());
                    dto.setName(user.getName());
                    dto.setEmail(user.getEmail());
                    dto.setRole(user.getRole());

                    return dto;
                })
                .toList();
    }

    @Override
    public UserResponseDTO getUser(Long id) {

        return userRepository.findById(id)
                .map(user -> {
                    UserResponseDTO dto = new UserResponseDTO();

                    dto.setId(user.getId());
                    dto.setName(user.getName());
                    dto.setEmail(user.getEmail());
                    dto.setRole(user.getRole());

                    return dto;
                })
                .orElseThrow();
    }

    @Override
    public void deleteUser(Long id) {

        userRepository.deleteById(id);
    }

    @Override
    public void reserveBook(ReservationRequest request) {

        Book book = bookRepository.findById(
                        request.getBookId())
                .orElseThrow();

        if (book.getAvailableCopies() > 0) {
            throw new RuntimeException(
                    "Book available. No reservation needed");
        }

        Reservation reservation =
                Reservation.builder()
                        .book(book)
                        .user(
                                userRepository.findById(
                                                request.getUserId())
                                        .orElseThrow())
                        .reservationDate(LocalDate.now())
                        .build();

        reservationRepository.save(reservation);
    }

    @Override
    public DashboardDTO dashboard() {

        return DashboardDTO.builder()
                .totalBooks(bookRepository.count())
                .totalUsers(userRepository.count())
                .totalIssuedBooks(issueRepository.count())
                .totalFines(fineRepository.count())
                .build();
    }

    @Override
    public void payFine(Long fineId) {

        Fine fine = fineRepository.findById(fineId)
                .orElseThrow();

        fine.setPaid(true);
        fine.setPaymentDate(LocalDate.now());

        fineRepository.save(fine);
    }
}