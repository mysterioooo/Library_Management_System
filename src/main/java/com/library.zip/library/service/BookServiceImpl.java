package com.library.service;

import com.library.dto.BookRequestDTO;
import com.library.dto.BookResponseDTO;
import com.library.dto.IssueBookRequest;
import com.library.entity.Book;
import com.library.entity.Fine;
import com.library.entity.IssueBook;
import com.library.entity.User;
import com.library.exception.ResourceNotFoundException;
import com.library.mapper.BookMapper;
import com.library.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BookServiceImpl
        implements BookService {

    private final BookRepository repository;
    private final BookMapper mapper;
    private final CategoryRepository categoryRepository;
    private final UserRepository userRepository;
    private final IssueBookRepository issueRepository;
    private final FineRepository fineRepository;

    @Override
    public BookResponseDTO create(BookRequestDTO dto) {

        Book book = mapper.toEntity(dto);

        book.setAvailableCopies(
                dto.getTotalCopies());

        return mapper.toDto(
                repository.save(book));
    }

    @Override
    public BookResponseDTO getById(Long id) {

        Book book = repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Book not found"));

        return mapper.toDto(book);
    }

    @Override
    public Page<BookResponseDTO> getAll(
            int page,
            int size,
            String sortBy,
            String direction) {

        Sort sort =
                direction.equalsIgnoreCase("asc")
                        ? Sort.by(sortBy).ascending()
                        : Sort.by(sortBy).descending();

        Pageable pageable =
                PageRequest.of(page, size, sort);

        return repository
                .findAll(pageable)
                .map(mapper::toDto);
    }

    @Override
    public BookResponseDTO update(Long id, BookRequestDTO dto) {

        Book book = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found"));

        // 1. Use the injected categoryRepository to find the Category entity by its ID
        com.library.entity.Category category = categoryRepository.findById(dto.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category not found"));

        book.setTitle(dto.getTitle());
        book.setAuthor(dto.getAuthor());
        book.setPublisher(dto.getPublisher());

        // 2. Pass the fetched 'category' object here instead of 'dto.getCategoryId()'
        book.setCategory(category);

        book.setIsbn(dto.getIsbn());
        book.setTotalCopies(dto.getTotalCopies());

        return mapper.toDto(repository.save(book));
    }

    @Override
    public void delete(Long id) {

        Book book = repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Book not found"));

        repository.delete(book);
    }

    @Override
    public List<BookResponseDTO> search(
            String keyword) {

        return repository
                .searchBooks(keyword)
                .stream()
                .map(mapper::toDto)
                .toList();
    }

    @Override
    public void issueBook(
            IssueBookRequest request) {

        User user =
                userRepository.findById(
                                request.getUserId())
                        .orElseThrow();

        Book book =
                repository.findById(
                                request.getBookId())
                        .orElseThrow();

        if (book.getAvailableCopies() <= 0) {
            throw new RuntimeException(
                    "Book not available");
        }

        book.setAvailableCopies(
                book.getAvailableCopies() - 1);

        repository.save(book);

        IssueBook issue =
                IssueBook.builder()
                        .user(user)
                        .book(book)
                        .issueDate(LocalDate.now())
                        .dueDate(
                                LocalDate.now()
                                        .plusDays(7))
                        .status("ISSUED")
                        .build();

        issueRepository.save(issue);
    }

    @Override
    public void returnBook(Long issueId) {

        IssueBook issue =
                issueRepository.findById(issueId)
                        .orElseThrow();

        Book book = issue.getBook();

        book.setAvailableCopies(
                book.getAvailableCopies() + 1);

        repository.save(book);

        issue.setReturnDate(
                LocalDate.now());

        issue.setStatus("RETURNED");

        issueRepository.save(issue);

        long overdueDays =
                ChronoUnit.DAYS.between(
                        issue.getDueDate(),
                        LocalDate.now());

        if (overdueDays > 0) {

            Fine fine =
                    Fine.builder()
                            .issueBook(issue)
                            .amount(overdueDays * 10.0)
                            .paid(false)
                            .build();

            fineRepository.save(fine);
        }
    }

    @Override
    public List<Fine> getAllFines() {
        return fineRepository.findAll();
    }
}