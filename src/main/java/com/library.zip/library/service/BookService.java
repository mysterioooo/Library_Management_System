package com.library.service;

import com.library.dto.BookRequestDTO;
import com.library.dto.BookResponseDTO;
import com.library.dto.IssueBookRequest;
import com.library.entity.Fine;
import org.springframework.data.domain.Page;

import java.util.List;

public interface BookService {

    BookResponseDTO create(BookRequestDTO dto);

    BookResponseDTO getById(Long id);

    Page<BookResponseDTO> getAll(int page, int size, String sortBy, String direction);

    void issueBook(IssueBookRequest request);

    BookResponseDTO update(Long id, BookRequestDTO dto);

    void returnBook(Long issueId);

    void delete(Long id);

    List<Fine> getAllFines();

    List<BookResponseDTO> search(String keyword);


}