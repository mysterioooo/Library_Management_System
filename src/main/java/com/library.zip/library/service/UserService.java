package com.library.service;

import com.library.dto.DashboardDTO;
import com.library.dto.ReservationRequest;
import com.library.dto.UserResponseDTO;
import org.springframework.stereotype.Service;

import java.util.List;


public interface UserService {

    List<UserResponseDTO> getAllUsers();

    UserResponseDTO getUser(Long id);

    void deleteUser(Long id);

    void reserveBook(ReservationRequest request);

    DashboardDTO dashboard();

    void payFine(Long fineId);

}
