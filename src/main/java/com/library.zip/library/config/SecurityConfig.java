package com.library.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@RequiredArgsConstructor
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration config)
            throws Exception {

        return config.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http)
            throws Exception {

        return http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth

                        .requestMatchers(
                                "/",
                                "/index.html",
                                "/register.html",
                                "/css/**",
                                "/js/**",
                                "/api/auth/**")
                        .permitAll()

                        .requestMatchers(
                                "/api/dashboard/**")
                        .hasAnyRole(
                                "ADMIN",
                                "LIBRARIAN")

                        .requestMatchers(
                                "/api/users/**")
                        .hasRole("ADMIN")

                        .requestMatchers(
                                "/api/books",
                                "/api/books/*")
                        .hasAnyRole(
                                "ADMIN",
                                "LIBRARIAN")

                        .requestMatchers(
                                "/api/issues/**")
                        .hasAnyRole(
                                "ADMIN",
                                "LIBRARIAN")

                        .requestMatchers(
                                "/api/reservations/**")
                        .hasAnyRole(
                                "ADMIN",
                                "LIBRARIAN",
                                "MEMBER")

                        .requestMatchers(
                                "/api/fines/**")
                        .hasAnyRole(
                                "ADMIN",
                                "LIBRARIAN")

                        .anyRequest()
                        .authenticated())
                .build();
    }
}